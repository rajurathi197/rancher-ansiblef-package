#!/bin/bash -e
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
export ANSIBLE_CONFIG=$DIR/ansible.cfg

rm -rf $HOME/rke2/ $HOME/.ansible

cmd_arguments=""

if [ $# -eq 0 ]
then
   cmd_arguments="--tag=install-all"
else
   cmd_arguments="$@"
fi

ansible-playbook playbooks/rancher-playbook.yaml $cmd_arguments --extra-vars "@vars/general-config.yaml" --extra-vars "@vars/vault-config.yaml" --connection=ssh --timeout=60